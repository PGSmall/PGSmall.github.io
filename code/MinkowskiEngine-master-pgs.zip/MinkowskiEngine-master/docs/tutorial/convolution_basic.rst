Convolution Basics
==================

In this tutorial, we will cover how to use a convolution layer and

Must be a positive integer or a list of positive integers.

`examples/convolution.py`
